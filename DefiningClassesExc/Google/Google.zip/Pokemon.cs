﻿public class Pokemon
{
    private string name;
    private string type;

    public string Name { get; set; }
    public string Type { get; set; }
}