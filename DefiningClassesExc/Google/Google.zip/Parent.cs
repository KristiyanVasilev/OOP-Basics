﻿using System;

public class Parent
{
    private string name;
    private string birthday;
    public string Name { get; set; }
    public string Birthday { get; set; }
}