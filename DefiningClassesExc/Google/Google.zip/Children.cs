﻿using System;

public class Children
{
    private string name;
    private string birthday;
    public string Name { get; set; }
    public string Birthday { get; set; }
}