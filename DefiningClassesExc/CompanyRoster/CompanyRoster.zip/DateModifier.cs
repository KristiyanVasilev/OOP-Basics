﻿using System;

public class DateModifier
{
    internal static object CalculateDifference(DateTime firstDate, DateTime secondDate)
    {
        return Math.Abs((firstDate - secondDate).TotalDays);
    }
}
